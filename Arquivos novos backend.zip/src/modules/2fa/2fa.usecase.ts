import { Request, Response } from "express";
import { prismaCient } from "../../infra/database/prismaClient";
import crypto from 'crypto'
const sendMail = require('../../libs/sendEmail')
const bcrypt = require('bcryptjs')

export class TwoFactorAuthUseCase {

    constructor() {}

    async encrypt(token: string): Promise<string> {
        const salt = await bcrypt.genSalt(12)
        const tokenHash = await bcrypt.hash(token, salt)
        return tokenHash 
    }

    async sendToken(membership_number: string, response: Response){

        
    }

    execute(response: Response, request: Request) {
        const membership_number = request.params.membership_number
        this.sendToken(membership_number, response)
    }
}
